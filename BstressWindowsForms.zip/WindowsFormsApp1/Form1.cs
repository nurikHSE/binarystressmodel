﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using SharpGL;
using WindowsFormsApp1.Graph;
using WindowsFormsApp1.Computation;
using WindowsFormsApp1.Options;
using System.Drawing.Imaging;
using System.IO;
using SharpGL.SceneGraph.Assets;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static Random random = new Random();
        public List<Vertex> list_of_nodes = new List<Vertex>();
        public List<Edge> list_of_edges = new List<Edge>();
        // по умолчанию, граф двудольный.
        public static bool Type_Of_Graph = true;
        //коэфициент альфа
        public static double Alpha_value;
        //номер текстуры
        int rtri = 1;
        //  The texture identifier.
        Texture texture = new Texture();
        // массив из тестур
        static string[] images = new string[20];
        // определяет, что рисовать в openGl
        public static bool flag=true;
        
        /// <summary>
        /// конструктор основной виндовс формы
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            openGLControl1.Visible = false;
            draw.Visible = false;          
            for (int i = 0; i < 20; i++)
            {
                //string startupPath = Environment.CurrentDirectory+"\\gifs";
                //string str = 
                var exePath = AppDomain.CurrentDomain.BaseDirectory;
                var path = Path.Combine(exePath, $"..\\..\\gifs\\pic{i + 1}.bmp");
                images[i] = path;
            }        
        }
  
        /// <summary>
        /// визуализация с помощью OpenGL
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void openGLControl1_OpenGLDraw(object sender, RenderEventArgs args)
        {        
            if (flag)
            {
                // Создаем экземпляр
                OpenGL gl = openGLControl1.OpenGL;
                // Очистка экрана и буфера глубин
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
                // белый цвет нашего окна
                gl.ClearColor(1, 1, 1, 0);
                // Сбрасываем модельно-видовую матрицу
                gl.LoadIdentity();
                gl.Translate(0f, 0f, -3f);         
                //  A bit of extra initialisation here, we have to enable textures.
                gl.Enable(OpenGL.GL_TEXTURE_2D);
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0f, 1.0f, 1.0f);
                gl.TexCoord(0.0f, 0.0f); gl.Vertex(-1.5f, 1.0f);
                gl.TexCoord(1.0f, 0.0f); gl.Vertex(1.5f, 1.0f);
                gl.TexCoord(1.0f, 1.0f); gl.Vertex(1.5f, -1.0f);
                gl.TexCoord(0.0f, 1.0f); gl.Vertex(-1.5f, -1.0f);
                gl.End();

                EventArgs obj = new EventArgs();
                changethetexture_Click(sender, obj);
                fileToolStripMenuItem.Enabled = false;
                helpToolStripMenuItem.Enabled = false;
                optionsToolStripMenuItem.Enabled = false;
            }
            else
            {
                // Создаем экземпляр
                OpenGL gl = openGLControl1.OpenGL;
                // Очистка экрана и буфера глубин
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
                // белый цвет нашего окна
                gl.ClearColor(0, 0, 0, 0);
                // Сбрасываем модельно-видовую матрицу
                gl.LoadIdentity();
                // Двигаем перо вглубь экрана
                gl.Translate(-list_of_nodes[0].X, -list_of_nodes[0].Y, -2.3f);
                texture.Destroy(gl);

                //ребра
                gl.Enable(OpenGL.GL_LINE_SMOOTH);
                gl.LineWidth(1);
                gl.Begin(OpenGL.GL_LINES);
                gl.Color(1f, 1f, 1f);
                for (int i = 0; i < list_of_edges.Count; i++)
                {
                    gl.Vertex(list_of_edges[i].First_node.X, list_of_edges[i].First_node.Y);
                    gl.Vertex(list_of_edges[i].Second_node.X, list_of_edges[i].Second_node.Y);
                }
                gl.End();

                //вершины
                gl.Enable(OpenGL.GL_POINT_SMOOTH);
                gl.PointSize(8f);
                gl.Begin(OpenGL.GL_POINTS);
                //gl.Color(random.NextDouble(), random.NextDouble(), random.NextDouble());
                for (int i = 0; i < list_of_nodes.Count; i++)
                {
                    if (list_of_nodes[i].Color == 1)
                    {
                        gl.Color(1f, 0f, 1f);
                        gl.Vertex(list_of_nodes[i].X, list_of_nodes[i].Y);
                    }
                    else
                    {
                        gl.Color(0f, 1.0f, 1.0f);
                        gl.Vertex(list_of_nodes[i].X, list_of_nodes[i].Y);
                    }
                }
                gl.End();
                fileToolStripMenuItem.Enabled = true;
                helpToolStripMenuItem.Enabled = true;
                optionsToolStripMenuItem.Enabled = true;
            }
        }

        /// <summary>
        /// сохранение графа как изображение
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveAsImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openGLControl1.Visible && list_of_nodes.Count > 0)
            {
                SaveFileDialog saveImage = new SaveFileDialog();
                saveImage.Filter = "JPeg Format (*.jpeg)|*.jpeg|PNG Format (*.png)|*.png";
                saveImage.Title = "Сохранить файл как изображение";
                Bitmap bitmap = new Bitmap(openGLControl1.Width, openGLControl1.Height);
                openGLControl1.DrawToBitmap(bitmap, new Rectangle(0, 0, openGLControl1.Width, openGLControl1.Height));
                if (saveImage.ShowDialog() == DialogResult.OK) //Use this to prevent exception on Cancel click
                {
                    if (saveImage.FileName != "")
                    {
                        FileStream fs = (FileStream)saveImage.OpenFile();
                        switch (saveImage.FilterIndex)
                        {
                            case 1:
                                bitmap.Save(fs, ImageFormat.Jpeg);
                                break;
                            case 2:
                                bitmap.Save(fs, ImageFormat.Png);
                                break;
                        }
                        fs.Close();
                        MessageBox.Show("Файл успешно сохранен! ", "Cохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Прежде чем сохранять как изображение, пожалуйста, изобразите граф, считав его с файла" +
                    " (в формате .tgf, или .dot, или .gml).", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        /// <summary>
        /// метод для открытия в трех файлах
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter= "TGF Format (*.tgf)|*.tgf|DOT Format (*.dot)|*.dot|GML Format (*.gml)|*.gml";
            openFile.Title = "Открыть файл для чтения графа";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                // если уже что-то нарисовано, я очищаю все
                if (list_of_nodes.Count>0 || flag)
                {
                    list_of_nodes.Clear();
                    list_of_edges.Clear();
                    openGLControl1.Visible = false;

                    fileToolStripMenuItem.Enabled = true;
                    helpToolStripMenuItem.Enabled = true;
                    optionsToolStripMenuItem.Enabled = true;
                }
                StreamReader stream = new System.IO.StreamReader(openFile.FileName);
                // на всякий случай
                try
                {
                    switch (openFile.FilterIndex)
                    {
                        case 1: TGF_format(stream); break;
                        case 2: DOT_format(stream); break;
                        case 3: GML_format(stream); break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        /// <summary>
        /// метод, для считывая графа в формате TGF
        /// </summary>
        /// <param name="stream"></param>
        void TGF_format(StreamReader stream)
        {
            string line;
            string[] lineWords;
            // Метка, пока не увидаит "#"
            bool flag = true;
            while ((line = stream.ReadLine()) != null)
            {
                if (line == "")
                    continue;
                lineWords = line.Split(' ');
                if (line == "#")
                {
                    flag = false;
                    continue;
                }
                if (flag)
                {
                    int number_of_node;
                    if (int.TryParse(lineWords[0], out number_of_node))
                    {
                        var node = new Vertex(random.Next(0, 10), random.Next(0, 10), number_of_node, number_of_node.ToString());
                        list_of_nodes.Add(node);
                    }
                }
                else
                {
                    int number_of_node_1;
                    int number_of_node_2;
                    if (int.TryParse(lineWords[0], out number_of_node_1) && int.TryParse(lineWords[1], out number_of_node_2))
                    {
                        var edge = new Edge(list_of_nodes[number_of_node_1 - 1], list_of_nodes[number_of_node_2 - 1]);
                        list_of_edges.Add(edge);
                    }
                }
            }
            Checking_list();
        }
        /// <summary>
        /// парсим dot format без атрибут
        /// </summary>
        /// <param name="stream"></param>
        void DOT_format(StreamReader stream)
        {
            // парсим dot format без атрибутов
            string line;
            string[] lineWords;
            const char beginning_description = '{';
            const char theend_of_description = '}';
            const char dotcomma = ';';
            const char space = ' ';
            const char quotes = '"'; 
            const string label = "->";
            int number_of_nodes = 0;
            while ((line = stream.ReadLine()) != null)
            {
                // если строка пустая, то пропускаю
                if (line == "") continue;
                // игнорирую атрибуты
                if (line.Contains("["))
                    line=line.Remove(line.IndexOf('['));
                // множество ребер
                if (line.Contains(label))
                {
                    lineWords = line.Split(new string[]{label}, StringSplitOptions.None);
                    for (int i = 0; i < lineWords.Length; i++)
                    {
                        lineWords[i] = lineWords[i].Trim(new char[] { dotcomma, space, quotes });
                    }
                    // формат, где нет избытычного описания графа(например,a -> b -> c)
                    if (lineWords.Length > 2)
                    {
                        for (int i = 0; i < lineWords.Length; i++)
                        {
                            var node = new Vertex(random.Next(20), random.Next(20), ++number_of_nodes, lineWords[i]);
                            list_of_nodes.Add(node);
                        }
                        for (int i = 0; i < lineWords.Length-1; i++)
                        {
                            var edge = new Edge(list_of_nodes[i], list_of_nodes[i+1]);
                            list_of_edges.Add(edge);
                        }
                    }
                    // формат с избыточным описанием
                    else
                    {
                        int index_of_first_node=0;
                        int index_of_second_node=0;
                        for (int i = 0; i < list_of_nodes.Count; i++)
                        {
                            if (list_of_nodes[i].ID == lineWords[0])
                                index_of_first_node = i;
                            if (list_of_nodes[i].ID == lineWords[1])
                                index_of_second_node = i;
                        }
                        var edge = new Edge(list_of_nodes[index_of_first_node], list_of_nodes[index_of_second_node]);
                        list_of_edges.Add(edge);
                    }
                }
                // множество вершин  
                else
                {
                    if (line.Contains("graph")  || line.Contains("=")||line.Contains("node") || line.Contains("edge") || 
                        line.Contains(theend_of_description.ToString())|| line.Contains(beginning_description.ToString()))
                        continue;
                    line = line.Trim(new char[] {space, dotcomma, quotes});
                    string id_of_vertex = line;
                    var node = new Vertex(random.Next(20), random.Next(20), ++number_of_nodes, id_of_vertex);
                    list_of_nodes.Add(node);
                }
            }
            Checking_list();
        }
        /// <summary>
        /// считывание формата GML
        /// </summary>
        /// <param name="stream"></param>
        void GML_format(StreamReader stream)
        {
            string line;
            int number_of_node = 0;
            string[] linewords_id_of_node;
            //это временный лист вершин для хранения вершин ребер
            List<Vertex> list_of_first_node = new List<Vertex>();
            List<Vertex> list_of_second_node = new List<Vertex>();
            while ((line = stream.ReadLine()) != null)
            {
                //if (line.Contains("directed"))
                //    throw new ArgumentException("Граф ориентированный!");
                if (line.Contains("id"))
                {
                    linewords_id_of_node = line.Split(' ');
                    var node = new Vertex(random.Next(100), random.Next(100), ++number_of_node, linewords_id_of_node[1]);
                    list_of_nodes.Add(node);
                }
                if (line.Contains("source"))
                {
                    linewords_id_of_node = line.Split(' ');
                    var node1 = new Vertex(random.Next(100), random.Next(100), 0, linewords_id_of_node[1]);
                    list_of_first_node.Add(node1);
                }
                if (line.Contains("target"))
                {
                    linewords_id_of_node = line.Split(' ');
                    var node2 = new Vertex(random.Next(100), random.Next(100), 0, linewords_id_of_node[1]);
                    list_of_second_node.Add(node2);
                }
            }
            int number_first_node = 0;
            int number_second_node = 0;
            for (int i = 0; i < list_of_first_node.Count; i++)
            {
                for (int j = 0; j < list_of_nodes.Count; j++)
                {
                    if (list_of_first_node[i].ID == list_of_nodes[j].ID)
                        number_first_node = j;
                    if (list_of_second_node[i].ID == list_of_nodes[j].ID)
                        number_second_node = j;
                }
                var edge = new Edge(list_of_nodes[number_first_node], list_of_nodes[number_second_node]);
                list_of_edges.Add(edge);
            }
            Checking_list();
        }
        /// <summary>
        /// метод для проверки, что граф не пуст
        /// </summary>
        void Checking_list()
        {
            // самое оптимальное(по умолчанию) значение альфа по статьи - это количество вершин графа 
            if (Alpha_value == 0)
                Alpha_value = list_of_nodes.Count;
            // кнопка рисования становится видимой 
            if (list_of_nodes.Count > 0)
                draw.Visible = true;
            else
            {
                MessageBox.Show("Файл пуст!\nПожалуйста, проверьте входной файл.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// метод для потверждения привыходе из программы 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (flag && openGLControl1.Visible)
                e.Cancel = false;
            else
            {
                var result = new DialogResult();
                result = MessageBox.Show("Вы точно хотите выйти?", "Внимание",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }
        /// <summary>
        /// сохранение графа в формате .gml
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openGLControl1.Visible && list_of_nodes.Count > 0)
            {
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.Filter = "GML format(Graph Modeling Language) (*.gml)|*.gml";
                saveFile.Title = "Сохранить граф в файле";
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    TextWriter str_writer = new StreamWriter(saveFile.FileName);
                    str_writer.WriteLine("graph [");
                    for (int i = 0; i < list_of_nodes.Count; i++)
                    {
                        string nodes = $"  node [\n    id {list_of_nodes[i].ID}\n    graphics [\n      center [ x {list_of_nodes[i].X} y {list_of_nodes[i].Y} ]" +
                            $"\n    ]\n  ]";
                        str_writer.WriteLine(nodes);
                    }
                    for (int i = 0; i < list_of_edges.Count; i++)
                    {
                        string edge = $"  edge [\n    source {list_of_edges[i].First_node.ID}\n    target {list_of_edges[i].Second_node.ID}\n  ]";
                        str_writer.WriteLine(edge);
                    }
                    str_writer.WriteLine("]");
                    str_writer.Close();
                    MessageBox.Show("Файл успешно сохранен.", "Сохранение в файле", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Чтоб сохранить граф в файле(в формате .gml), Вам нужно визуализировать " +
                    "граф, считав его с файла, другими словами, применив метод двойного напряжения.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        /// <summary>
        /// метод для удаление данных
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result_of_dialog = new DialogResult();
            if (openGLControl1.Visible)
            {
                result_of_dialog = MessageBox.Show("Вы точно хотите удалить все данные?", "Внимание",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question);
                if (result_of_dialog == DialogResult.Yes)
                {
                    openGLControl1.Visible = false;
                    draw.Visible = false;
                    list_of_edges.Clear();
                    list_of_nodes.Clear();
                }
            }
        }
        /// <summary>
        /// метод для изменений настроек графа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OptionsForm options = new OptionsForm(this);
            options.ShowDialog();
        }
        /// <summary>
        /// вызов помощи
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Программа является курсовой работой студента первого курса бакалавриата образовательной программы " +
                "\"Программная инженерия\" группы БПИ_171 Гуломкодирова Нуруллохона.\nЕсли у Вас возникли вопросы или хотели бы оставить комментарии " +
                "касательно программы, то прошу Вас связаться по электронному адресу: nfgulomkodirov@edu.hse.ru " +
                " или nurik_19988@bk.ru.\nСпасибо.", "Помощь", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        /// <summary>
        /// вычисление прваой части СЛАУ
        /// </summary>
        /// <param name="V"></param>
        /// <param name="E"></param>
        /// <param name="alpha"></param>
        /// <returns></returns>
        static double[,] Leftpart(List<Vertex> V, List<Edge> E, double alpha)
        {
            double[,] matrix_A = new double[V.Count-1, V.Count-1];
            matrix_A = LeftPart.Matrix_A(V, E, alpha);
            return matrix_A;
        }
        /// <summary>
        /// проверка на двудольность графа
        /// </summary>
        void bipartite_validation()
        {
            double[,] matrix = LeftPart.Laplacian_Mtrx(list_of_nodes.Count, list_of_edges);
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (i == j)
                        matrix[i, j] = 0;
                    else matrix[i, j] = -matrix[i, j];
                }
            BibartiteGraph bibartite = new BibartiteGraph(matrix);
            if (!bibartite.Checking_Bibartite())
                    throw new ArgumentException("Граф не двудольный!");
            else
            {
                // указываю вершин в два цвета, в зависимости какой множестве принадлежит данная вершина  
                for (int i = 0; i < list_of_nodes.Count; i++)
                {
                        list_of_nodes[i].Color = bibartite.Color[i];
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void draw_Click(object sender, EventArgs e)
        {
            //кнопка становится невидимой
            draw.Visible = false;
            // если граф двудолный в настройках, то проверяю на двудольность
            if (Type_Of_Graph)
            {
                try
                {
                    bipartite_validation();
                }
                catch (ArgumentException ex)
                {
                    MessageBox.Show($"{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            if (!flag)
                flag = true;
            openGLControl1.Visible = true;
            DisplayResultAsync();
        }
        /// <summary>
        /// асихронный метод
        /// </summary>
        async void DisplayResultAsync()
        {
            list_of_nodes = await ConjugateGradient.Iterration(Leftpart(list_of_nodes, list_of_edges, Alpha_value), list_of_nodes);
            flag = false;
            openGLControl1.Invalidate();
        }
        /// <summary>
        /// кнопка для изменения текстуры
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void changethetexture_Click(object sender, EventArgs e)
        {           
            if (rtri >= int.MaxValue)
                rtri = 1;
            OpenGL gl = openGLControl1.OpenGL;
            //  Destroy the existing texture.
            texture.Destroy(openGLControl1.OpenGL);
            //  Create a new texture.
            texture.Create(gl, images[(++rtri) % 20]);
            //  Redraw.
            openGLControl1.Invalidate();
            gl.TexParameter(OpenGL.GL_TEXTURE_2D, OpenGL.GL_TEXTURE_MIN_FILTER, OpenGL.GL_LINEAR);
            gl.TexParameter(OpenGL.GL_TEXTURE_2D, OpenGL.GL_TEXTURE_MAG_FILTER, OpenGL.GL_LINEAR);
        }
    }
}
