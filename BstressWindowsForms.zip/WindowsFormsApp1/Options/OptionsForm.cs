﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1.Options
{
    public partial class OptionsForm : Form
    {
        Form1 main_form = new Form1();
        /// <summary>
        /// конструктор класса OptionsForm
        /// </summary>
        /// <param name="main_form"></param>
        public OptionsForm(Form1 main_form)
        {
            InitializeComponent();
            // значение по умолчанию типа графа и значение альфа
            if (Form1.Type_Of_Graph)
                Bibartite_checking.Checked = true;
            else Bibartite_checking.Checked = false;
            // значение альфа
            ValueOfAlpha.Text = Form1.Alpha_value.ToString();
            this.main_form = main_form;
        }
        /// <summary>
        /// Настройки алгоритма(Сохроняет новые значения)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveNewValues_Click(object sender, EventArgs e)
        {          
            double alpha_for_validation;
            ValueOfAlpha.Text=ValueOfAlpha.Text.Replace('.', ',');
            if (double.TryParse(ValueOfAlpha.Text, out alpha_for_validation) && alpha_for_validation >= 0)
            {
                if (Bibartite_checking.Checked)
                    Form1.Type_Of_Graph = true;
                else Form1.Type_Of_Graph = false;
                Form1.Alpha_value = alpha_for_validation;
                if (main_form.list_of_nodes.Count > 0)
                {
                    main_form.draw.Visible = true;
                }
                Hide();
                Dispose();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите неотрицательное значение альфа.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
