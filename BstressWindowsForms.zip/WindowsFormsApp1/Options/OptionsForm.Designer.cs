﻿namespace WindowsFormsApp1.Options
{
    partial class OptionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionsForm));
            this.Save_new_values = new System.Windows.Forms.Button();
            this.alpha = new System.Windows.Forms.Label();
            this.ValueOfAlpha = new System.Windows.Forms.TextBox();
            this.Bibartite_checking = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Save_new_values
            // 
            this.Save_new_values.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Save_new_values.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Save_new_values.Location = new System.Drawing.Point(306, 165);
            this.Save_new_values.Name = "Save_new_values";
            this.Save_new_values.Size = new System.Drawing.Size(137, 33);
            this.Save_new_values.TabIndex = 0;
            this.Save_new_values.Text = "Сохранить";
            this.Save_new_values.UseVisualStyleBackColor = false;
            this.Save_new_values.Click += new System.EventHandler(this.saveNewValues_Click);
            // 
            // alpha
            // 
            this.alpha.AutoSize = true;
            this.alpha.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.alpha.Location = new System.Drawing.Point(26, 52);
            this.alpha.Name = "alpha";
            this.alpha.Size = new System.Drawing.Size(67, 20);
            this.alpha.TabIndex = 2;
            this.alpha.Text = "Альфа";
            // 
            // ValueOfAlpha
            // 
            this.ValueOfAlpha.Location = new System.Drawing.Point(99, 50);
            this.ValueOfAlpha.Name = "ValueOfAlpha";
            this.ValueOfAlpha.Size = new System.Drawing.Size(344, 22);
            this.ValueOfAlpha.TabIndex = 4;
            // 
            // Bibartite_checking
            // 
            this.Bibartite_checking.AutoSize = true;
            this.Bibartite_checking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bibartite_checking.Location = new System.Drawing.Point(40, 102);
            this.Bibartite_checking.Name = "Bibartite_checking";
            this.Bibartite_checking.Size = new System.Drawing.Size(323, 24);
            this.Bibartite_checking.TabIndex = 5;
            this.Bibartite_checking.Text = "Проверка графа на двудольность";
            this.Bibartite_checking.UseVisualStyleBackColor = true;
            // 
            // OptionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 245);
            this.Controls.Add(this.Bibartite_checking);
            this.Controls.Add(this.ValueOfAlpha);
            this.Controls.Add(this.alpha);
            this.Controls.Add(this.Save_new_values);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "OptionsForm";
            this.Text = "Настройки";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Save_new_values;
        private System.Windows.Forms.Label alpha;
        private System.Windows.Forms.TextBox ValueOfAlpha;
        private System.Windows.Forms.CheckBox Bibartite_checking;
    }
}