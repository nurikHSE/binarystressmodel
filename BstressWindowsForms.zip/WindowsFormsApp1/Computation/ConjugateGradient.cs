﻿using System;
using System.Collections.Generic;
using LinearSystems;
using WindowsFormsApp1.Graph;
using System.Linq;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Computation
{
    public class ConjugateGradient
    {
        /// <summary>
        /// метод, в котором происходит вычисление новых координатов вершин  при каждой итерации
        /// </summary>
        /// <param name="matrix_A"></param>
        /// <param name="present_list"></param>
        /// <param name="iter_number"></param>
        /// <returns></returns>
        /// 
        public static Task<List<Vertex>> Iterration(double[,] matrix_A, List<Vertex> present_list)
        {
            // солвер, которое поддерживает метод сопряженных градиентов для решения СЛАУ
            ModernIterativeMethods m = new ModernIterativeMethods();          
            return Task.Run(() =>
            {
                // количество итераций
                int iter_number1 = 0;
                // предыдущие значения
                double[] previous_x = new double[present_list.Count];
                double[] previous_y = new double[present_list.Count];
                do
                {
                    for (int j = 0; j < present_list.Count; j++)
                    {
                        previous_x[j] = present_list[j].X;
                        previous_y[j] = present_list[j].Y;
                    }
                    // правая часть 
                    double[] rightpart_x = RightPart.Vector_Bx(present_list);
                    double[] rightpart_y = RightPart.Vector_By(present_list);
                    // ответы
                    double[] answer_X = new double[present_list.Count - 1];
                    double[] answer_Y = new double[present_list.Count - 1];
                    // вычисление новых координат
                    m.ConjugateGradient(present_list.Count - 1, 1000, 0.0001, matrix_A, rightpart_x, answer_X);
                    m.ConjugateGradient(present_list.Count - 1, 1000, 0.0001, matrix_A, rightpart_y, answer_Y);
                    // присваиваю новые значения 
                    for (int i = 1; i < present_list.Count; i++)
                    {
                        present_list[i].X = answer_X[i - 1];
                        present_list[i].Y = answer_Y[i - 1];
                    }
                    iter_number1++;
                    if (iter_number1 >= 200)
                        break;
                } while (!Just(present_list, previous_x, previous_y));
                // просто присваиваю первой вершине значения второй вершины 
                previous_x[0] = present_list[1].X;
                previous_y[0] = present_list[1].Y;
                // нахожу max и min по оси OX и OY
                double max_x = previous_x.Max();
                double min_x = previous_x.Min();
                double max_y = previous_y.Max();
                double min_y = previous_y.Min();
                // теперь значения первой вершины - это центр графа
                present_list[0].X = (max_x + min_x) / 2;
                present_list[0].Y = (max_y + min_y) / 2;
                return present_list;
            });
        }            
        public static bool Just(List<Vertex> current, double[] previous_x, double[] previous_y)
        {
            bool flag = false;
            // прохожу по всем вершинам, чтобы проверить условия остановки цикла ( |p(t+1)-p(t)|/|p(t)|, где p(i) принадлежит V(множестве вершин) )
            for (int i = 1; i < current.Count; i++)
            {
                if ((Math.Abs(current[i].X - previous_x[i])) / (Math.Abs(previous_x[i])) < 0.001 && (Math.Abs(current[i].Y - previous_y[i])) / (Math.Abs(previous_y[i])) < 0.001)
                {
                    flag = true;
                    continue;
                }
                else
                {
                    break;
                }
            }
            return flag;
        }
    }
}
