﻿using System;
using System.Collections.Generic;
using WindowsFormsApp1.Graph;

namespace WindowsFormsApp1.Computation
{
    public class RightPart
    {
        /// <summary>
        /// вектор из координат вершин по оси ОХ(углы между каждой парой вершин, правая часть СЛАУ)
        /// </summary>
        /// <returns></returns>
        public static double[] Vector_Bx(List<Vertex> V)
        {
            // массив из координат всех вершин 
            double[] vector_Bx = new double[V.Count];
            // так как мы удаляем первую строку, то мы не учитываем координату первой вершины 
            double[] vector_Bx_clone = new double[V.Count - 1];
            for (int i = 0; i < V.Count; i++)
            {
                for (int j = 0; j < V.Count; j++)
                {
                    if (V[i].X == V[j].X && V[i].Y == V[j].Y)
                    {
                        // Если две вершины с одинаковыми координатами, то сдвигаю первую вершину на 0,1, чтоб избежать деление на ноль 
                        vector_Bx[i] += ((V[i].X + 0.1 - V[j].X)) / Math.Sqrt((Math.Pow((V[i].X + 0.1 - V[j].X), 2) + Math.Pow((V[i].Y + 0.1 - V[j].Y), 2)));
                    }
                    else
                        vector_Bx[i] += (V[i].X - V[j].X) / (Math.Sqrt((Math.Pow((V[i].X - V[j].X), 2) + Math.Pow((V[i].Y - V[j].Y), 2))));
                }
            }
            // копирую координату всех вершин, кроме первой вершины
            Array.Copy(vector_Bx, 1, vector_Bx_clone, 0, vector_Bx_clone.Length);
            return vector_Bx_clone;
        }
        /// <summary>
        /// Вектор  координат по оси ОУ, аналогично как в методе Vector_Bx
        /// </summary>
        /// <returns></returns>
        public static double[] Vector_By(List<Vertex> V)
        {
            double[] vector_By = new double[V.Count];
            double[] vector_By_clone = new double[V.Count - 1];
            for (int i = 0; i < V.Count; i++)
                for (int j = 0; j < V.Count; j++)
                {
                    if (V[i].X == V[j].X && V[i].Y == V[j].Y)
                    {
                        vector_By[i] += ((V[i].Y + 0.1 - V[j].Y)) / Math.Sqrt((Math.Pow((V[i].X + 0.1 - V[j].X), 2) + Math.Pow((V[i].Y + 0.1 - V[j].Y), 2)));
                    }
                    else
                        vector_By[i] += ((V[i].Y - V[j].Y)) / Math.Sqrt((Math.Pow((V[i].X - V[j].X), 2) + Math.Pow((V[i].Y - V[j].Y), 2)));
                }
            Array.Copy(vector_By, 1, vector_By_clone, 0, vector_By_clone.Length);
            return vector_By_clone;
        }
    }
}
