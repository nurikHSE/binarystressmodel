﻿using System.Collections.Generic;
using WindowsFormsApp1.Graph;

namespace WindowsFormsApp1.Computation
{
    public class LeftPart
    {
        /// <summary>
        /// Матрица_М, квадратичная форма, которая ограничивает G(p)
        /// </summary>
        /// <param name="number_vertices"></param>
        /// <returns></returns>
        public static double[,] Matrix_M(int number_vertices)
        {
            double[,] matrix = new double[number_vertices, number_vertices];
            for (int i = 0; i <= matrix.GetUpperBound(0); i++)
                for (int j = 0; j <= matrix.GetUpperBound(1); j++)
                {
                    if (i == j)
                        matrix[i, j] = number_vertices - 1;
                    else matrix[i, j] = -1;
                }
            return matrix;
        }
        /// <summary>
        /// Лапласиан матрица H(p)
        /// </summary>
        /// <param name="number_vertices"></param>
        /// <param name="E"></param>
        /// <returns></returns>
        public static double[,] Laplacian_Mtrx(int number_vertices, List<Edge> E)
        {
            double[,] matrix = new double[number_vertices, number_vertices];
            if (E.Count > 0)
            {
                for (int i = 0; i < E.Count; i++)
                {
                    matrix[(E[i].First_node.number_of_node) - 1, (E[i].Second_node.number_of_node) - 1] = -1;
                    matrix[(E[i].Second_node.number_of_node) - 1, (E[i].First_node.number_of_node) - 1] = -1;
                }
            }
            for (int i = 0; i < number_vertices; i++)
            {
                int degree_of_node = 0;
                for (int j = 0; j < number_vertices; j++)
                {
                    if (matrix[i, j] != 0 && i != j)
                    {
                        degree_of_node++;
                    }
                }
                matrix[i, i] = degree_of_node;
            }
            return matrix;
        }
        /// <summary>
        /// Матрица_A(левая часть СЛАУ, где А = (М + альфа * L) )
        /// </summary>
        /// <param name="matrix_m"></param>
        /// <param name="laplacian_m"></param>
        /// <param name="alpha"></param>
        /// <returns></returns>
        public static double[,] Matrix_A(List<Vertex> V, List<Edge> E, double alpha)
        {
            double[,] matrix = new double[V.Count - 1, V.Count - 1];
            double[,] matrix_m = Matrix_M(V.Count);
            double[,] laplacian_m = Laplacian_Mtrx(V.Count, E);
            for (int i = 0; i < V.Count - 1; i++)
            {
                for (int j = 0; j < V.Count - 1; j++)
                {
                    matrix[i, j] = matrix_m[i + 1, j + 1] + alpha * laplacian_m[i + 1, j + 1];
                }
            }
            return matrix;
        }
    }
}
