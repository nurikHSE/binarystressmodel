﻿
namespace WindowsFormsApp1.Graph
{
    public class Edge
    {
        /// <summary>
        /// первая вершина
        /// </summary>
        public Vertex First_node { get; private set; }
        /// <summary>
        /// вторая вершина
        /// </summary>
        public Vertex Second_node { get; private set; }
        /// <summary>
        /// конструктор класса Edge
        /// </summary>
        /// <param name="node1"></param>
        /// <param name="node2"></param>
        public Edge(Vertex node1, Vertex node2)
        {
            First_node = node1;
            Second_node = node2;
        }
    }
}
