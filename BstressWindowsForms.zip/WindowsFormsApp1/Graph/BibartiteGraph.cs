﻿
namespace WindowsFormsApp1.Graph
{
    public class BibartiteGraph
    {
        /// <summary>
        /// булевое значение для определания графа на двудольность 
        /// </summary>
        public bool Two { get; set; }
        /// <summary>
        /// матрица смежности
        /// </summary>
        public double[,] Matrix { get; private set; }
        /// <summary>
        /// массив из вершин графа, разделенный на два подмножество
        /// </summary>
        public int[] Color { get; private set; }
        /// <summary>
        /// конструктор класса BibartiteGraph
        /// </summary>
        /// <param name="graph"></param>
        public BibartiteGraph(double[,] graph)
        {
            Two = true;
            Matrix = graph;
            Color = new int[graph.GetLength(0)];
        }
        /// <summary>
        /// алгоритм обход в глубину, для разбиения на два подмножества 
        /// </summary>
        /// <param name="v"></param>
        void DFS(int v)
        {
            for (int i = 0; i < Matrix.GetLength(0); ++i)
                if (Matrix[v, i] == 1)
                {
                    if (Color[i] == 0)
                    {
                        Color[i] = 3 - Color[v];
                        DFS(i);
                    }
                    else if (Color[i] == Color[v])
                    {
                        Two = false;
                    }
                }
        }
        /// <summary>
        /// открытый метод для проверки на двудольность
        /// </summary>
        /// <returns></returns>
        public bool Checking_Bibartite()
        {
            for (int i = 0; i < Matrix.GetLength(0); i++)
                if (Color[i] == 0)
                {
                    Color[i] = 1;
                    DFS(i);
                }
            return Two;
        }
    }
}
