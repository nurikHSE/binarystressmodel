﻿
namespace WindowsFormsApp1.Graph
{
    public class Vertex
    {
        /// <summary>
        /// значение вершины по оси ОХ
        /// </summary>
        public double X { get; set; }
        /// <summary>
        /// значение вершины по оси OY
        /// </summary>
        public double Y { get; set; }
        /// <summary>
        /// номер вершины
        /// </summary>
        public int number_of_node { get; private set; }
        /// <summary>
        /// цвет вершин, если граф двудольный
        /// </summary>
        public int Color { get; set; }
        /// <summary>
        /// название вершины
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// конструктор класса Vertex
        /// </summary>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="number"></param>
        /// <param name="Id"></param>
        public Vertex(double X, double Y, int number, string Id)
        {
            this.X = X;
            this.Y = Y;
            number_of_node = number;
            ID = Id;
        }
    }
}
